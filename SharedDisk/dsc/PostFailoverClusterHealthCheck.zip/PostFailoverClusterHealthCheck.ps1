configuration PostFailoverClusterHealthCheck
{
    param
    (
        [Parameter(Mandatory)]
        [String]$ClusterName,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [Parameter(Mandatory)] [ValidateRange(2, 4)]
        [Int]$ClusterNodesNum, 

        [String[]]$ClusterNodeName = 'localhost'
    )

    try 
    {
        Get-ItemPropertyValue 'HKLM:\SOFTWARE\Microsoft\Windows Azure' -Name dscPreboot
    } 
    catch 
    {
        Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows Azure' -Name dscPreboot -Value $True
        Start-Sleep -Seconds 30
        Restart-Computer -Force
    }

    Import-DscResource -ModuleName PSDesiredStateConfiguration, ComputerManagementDsc, ActiveDirectoryDsc, NetworkingDsc

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$($Admincreds.UserName)@${DomainName}", $Admincreds.Password)
   
    Node $ClusterNodeName
    {

        Script dscRebootFix1 {
            SetScript            = "`$taskTrigger = New-ScheduledTaskTrigger -AtStartup; `$taskAction = New-ScheduledTaskAction -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -Argument '-Command Start-Sleep 300; Restart-Computer -Force'; `$taskSettings = New-ScheduledTaskSettingsSet; `$taskCreds = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; `$task = New-ScheduledTask -Action `$taskAction -Trigger `$taskTrigger -Settings `$taskSettings -Principal `$taskCreds; Register-ScheduledTask -TaskName 'dscRebootFix1' -InputObject `$task"
            TestScript           = "if ((Get-ScheduledTask -TaskName 'dscRebootFix1' -ErrorAction SilentlyContinue).State -ne `$null) { Stop-ScheduledTask -TaskName 'dscRebootFix1'; (Disable-ScheduledTask -TaskName 'dscRebootFix1').State -eq 'Disabled' } else { `$false }"
            GetScript            = "@{Ensure = if ((Get-ScheduledTask -TaskName 'dscRebootFix1' -ErrorAction SilentlyContinue).State -ne `$null) {'Present'} else {'Absent'}}"
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
            DependsOn  = "[Script]dscRebootFix1"
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature FCCmd {
            Name = "RSAT-Clustering-CmdInterface"
            Ensure = "Present"
        }

        WindowsFeature FCMgmt {
            Name = "RSAT-Clustering-Mgmt"
            Ensure = "Present"
        }


        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]FCMgmt"
        }


        Script ClusterStateCheck 
            {
              SetScript  =  {
               
                if ((Get-Cluster).Count -eq 0)
                {
                 throw "get-cluster count returned 0. no cluster running on the machine"
                }

                if ((Get-ClusterNode | Where-Object {$_.State -eq "Up"}).Count -ne $using:ClusterNodesNum)
                {
                  throw "Number of cluster nodes for the cluster=" + $using:ClusterName + " is =" + (Get-ClusterNode -Cluster $using:ClusterName).Count.ToString();
                }
             }
             TestScript = {
                $filename = "C:\TestFile" + $($(get-date).ToUniversalTime()).ToString('yyyyMMddTHHmmssZ') + ".txt";
                $sw = New-Object System.IO.StreamWriter("${filename}")
               
                if ((Get-Cluster).Count -eq 0)
                {
                  $sw.WriteLine("Not able to get the cluster using cluster name passed=" + $using:ClusterName);
                  $sw.close();
                  return $false
                }

                if ((Get-ClusterNode | Where-Object {$_.State -eq "Up"}).Count -ne $using:ClusterNodesNum)
                {
                  $sw.WriteLine("Number of cluster nodes for the cluster=" + $using:ClusterName + " is =" + (Get-ClusterNode -Cluster $using:ClusterName).Count.ToString());
                  $sw.close();
                  return $false
                }

                $sw.WriteLine("cluster validations success for current node!!");
                $sw.close();
                return $true;
             }
             GetScript  = {
              if ((Get-Cluster).Count -gt 0) 
              {
                return @{'Result' = 'Running'}
              }
              return @{'Result' = 'Running'}
             }
             PsDscRunAsCredential = $DomainCreds
             DependsOn  = "[WindowsFeature]ADPS"
            }

        LocalConfigurationManager 
        {
            ActionAfterReboot = "ContinueConfiguration"
            ConfigurationMode = "ApplyAndMonitor"
            RebootNodeIfNeeded = $True
        }

    }
}