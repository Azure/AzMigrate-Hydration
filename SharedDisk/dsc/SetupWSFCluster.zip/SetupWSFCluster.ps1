configuration SetupWSFCluster
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName = "dgqldomain.com",

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [Parameter(Mandatory)]
        [String]$ClusterName = "",

        [Parameter(Mandatory)]
        [String]$VMNamesPrefix,

        [Parameter(Mandatory)]
        [Int]$VMCount,

        [Parameter(Mandatory)]
        [ValidateSet("Node", "Disk", "Cloud", "FileShare")]
        [String]$WitnessType,

        [Parameter(Mandatory)]
        [Int]$ListenerProbePort,

        [String]$WitnessStorageName,

        [String]$WitnessFileShareCompletePath,

        [System.Management.Automation.PSCredential]$WitnessStorageKey,

        [String]$ClusterGroup = "${ClusterName}-group",

        [String[]]$nodeName = 'localhost', 

        [String]$ClusterIPName = "IP Address Cls"
    )

    try 
    {
        Get-ItemPropertyValue 'HKLM:\SOFTWARE\Microsoft\Windows Azure' -Name dscPreboot
    } 
    catch 
    {
        Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows Azure' -Name dscPreboot -Value $True
        Start-Sleep -Seconds 30
        Restart-Computer -Force
    }

    Import-DscResource -ModuleName PSDesiredStateConfiguration, ComputerManagementDsc, ActiveDirectoryDsc
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$($Admincreds.UserName)@${DomainName}", $Admincreds.Password)
    [System.Collections.ArrayList]$CNodes = @()
    For ($count = 1; $count -lt $VMCount; $count++) {
        $CNodes.Add($VMNamesPrefix + $Count.ToString())
    }


    Write-Verbose -Message ('Access keys  {0}' -f ${witnesssakeys})
    
    Node $nodeName 
    {
        Script dscRebootFix1 {
            SetScript            = "`$taskTrigger = New-ScheduledTaskTrigger -AtStartup; `$taskAction = New-ScheduledTaskAction -Execute 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -Argument '-Command Start-Sleep 300; Restart-Computer -Force'; `$taskSettings = New-ScheduledTaskSettingsSet; `$taskCreds = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; `$task = New-ScheduledTask -Action `$taskAction -Trigger `$taskTrigger -Settings `$taskSettings -Principal `$taskCreds; Register-ScheduledTask -TaskName 'dscRebootFix1' -InputObject `$task"
            TestScript           = "if ((Get-ScheduledTask -TaskName 'dscRebootFix1' -ErrorAction SilentlyContinue).State -ne `$null) { Stop-ScheduledTask -TaskName 'dscRebootFix1'; (Disable-ScheduledTask -TaskName 'dscRebootFix1').State -eq 'Disabled' } else { `$false }"
            GetScript            = "@{Ensure = if ((Get-ScheduledTask -TaskName 'dscRebootFix1' -ErrorAction SilentlyContinue).State -ne `$null) {'Present'} else {'Absent'}}"
        }
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
            DependsOn  = "[Script]dscRebootFix1"
        }
        WindowsFeature AddRemoteServerAdministrationToolsClusteringPowerShellFeature 
        {
            Name      = "RSAT-Clustering-PowerShell"
            Ensure    = "Present"
            DependsOn = "[WindowsFeature]FC"
        }
        WindowsFeature AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature 
        {
            Name      = "RSAT-Clustering-CmdInterface"
            Ensure    = "Present"
            DependsOn = "[WindowsFeature]AddRemoteServerAdministrationToolsClusteringPowerShellFeature"
        }
        WindowsFeature FCMgmt {
            Name = "RSAT-Clustering-Mgmt"
            Ensure = "Present"
            DependsOn  = "[WindowsFeature]AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature"
        }
        WindowsFeature FS
        {
            Name = "FS-FileServer"
            Ensure = "Present"
            DependsOn  = "[WindowsFeature]FCMgmt"
        }     
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            DependsOn  = "[WindowsFeature]FS"
        }
        WaitForADDomain DscForestWait 
        { 
            DomainName              = $DomainName 
            Credential              = $DomainCreds
            WaitForValidCredentials = $True
            WaitTimeout             = 600
            RestartCount            = 3
            DependsOn               = "[WindowsFeature]ADPS"
        }
        Computer DomainJoin
        {
            Name       = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn  = "[WaitForADDomain]DscForestWait"
        }

        
        $clusterActiveDirName = $ClusterName[0..14] -join ''

        Script CreateCluster {
            SetScript        = { 
                try {
                   Get-ADComputer -Identity $using:clusterActiveDirName | Remove-AdComputer
                }
                catch {
                }

                New-Cluster -Name $using:ClusterName -Node ${env:COMPUTERNAME} -NoStorage

                }
            TestScript           = "(Get-Cluster -ErrorAction SilentlyContinue).Name -eq '${ClusterName}'"
            GetScript            = "@{Ensure = if ((Get-Cluster -ErrorAction SilentlyContinue).Name -eq '${ClusterName}') {'Present'} else {'Absent'}}"
            PsDscRunAsCredential = $DomainCreds
            DependsOn            = @("[Computer]DomainJoin","[WindowsFeature]FC","[WindowsFeature]AddRemoteServerAdministrationToolsClusteringPowerShellFeature")
        }
        foreach ($cnode in $CNodes) 
        {
            Script "AddClusterNode_${cnode}" 
            {
                SetScript            = "Add-ClusterNode -Name ${cnode} -NoStorage"
                TestScript           = "'${cnode}' -in (Get-ClusterNode).Name"
                GetScript            = "@{Ensure = if ('${cnode}' -in (Get-ClusterNode).Name) {'Present'} else {'Absent'}}"
                PsDscRunAsCredential = $DomainCreds
                DependsOn            = "[Script]CreateCluster"
            }
        }
        Script FormatSharedDisks 
        {
            SetScript  = "Get-Disk | Where-Object PartitionStyle -eq 'RAW' | Initialize-Disk -PartitionStyle GPT -PassThru -ErrorAction SilentlyContinue | New-Partition -AssignDriveLetter -UseMaximumSize -ErrorAction SilentlyContinue | Format-Volume -FileSystem NTFS -Confirm:`$false"
            TestScript = "(Get-Disk | Where-Object PartitionStyle -eq 'RAW').Count -eq 0"
            GetScript  = "@{Ensure = if ((Get-Disk | Where-Object PartitionStyle -eq 'RAW').Count -eq 0) {'Present'} else {'Absent'}}"
            PsDscRunAsCredential = $DomainCreds
            DependsOn  = "[Script]CreateCluster"
        }
        Script AddClusterDisks 
        {
            SetScript  = "Get-ClusterAvailableDisk | Add-ClusterDisk"
            TestScript = "(Get-ClusterAvailableDisk).Count -eq 0"
            GetScript  = "@{Ensure = if ((Get-ClusterAvailableDisk).Count -eq 0) {'Present'} else {'Absent'}}"
            PsDscRunAsCredential = $DomainCreds
            DependsOn  = "[Script]FormatSharedDisks"
        }

        if ($WitnessType -ne 'Node')
        {
         
             $witnesssakeys = ""
             if ($WitnessStorageKey -ne $null -and $WitnessType -eq 'Cloud')
             {
                    $witnesssakeys = $WitnessStorageKey.GetNetworkCredential().Password;
             }

             
            #  if ($WitnessType -eq 'FileShare')
            #  {
            #   $WitnessFileShareCompletePath = $WitnessFileShareCompletePath -replace '\\(.)', '$1' 
            #  }

            Script ClusterWitness 
            {
              SetScript  =  {
                $sw = New-Object System.IO.StreamWriter("C:\TestFile.txt")
                $sw.WriteLine("Witness type " + $using:WitnessType)
            
                if ($using:WitnessType -eq 'Cloud')
                { 
                    $sw.WriteLine("cloud witness with storage name " + $using:WitnessStorageName)
                    Set-ClusterQuorum -CloudWitness -AccountName $using:WitnessStorageName -AccessKey $using:witnesssakeys;
                    
                } 
            
                if ($using:WitnessType -eq 'Disk')
                { 
                    $sw.WriteLine("Disk witness")
                    Set-ClusterQuorum -DiskWitness $(Get-ClusterResource | ? ResourceType -eq 'Physical Disk' | Sort-Object Name | Select-Object -Last 1).Name;
                }
                
                if ($using:WitnessType -eq 'FileShare')
                {
                    $sw.WriteLine("FileShare witness " + $using:WitnessFileShareCompletePath)
                    Set-ClusterQuorum -NodeAndFileShareMajority $using:WitnessFileShareCompletePath;
                    
                }
                Write-Verbose -Message ('Successfully set the witness {0}' -f ${WitnessType})
                $sw.close();
             }
             TestScript = "((Get-ClusterQuorum).QuorumResource).Count -gt 0"
             GetScript  = "@{Ensure = if (((Get-ClusterQuorum).QuorumResource).Count -gt 0) {'Present'} else {'Absent'}}"
             PsDscRunAsCredential = $DomainCreds
             DependsOn  = "[Script]AddClusterDisks"
            }

        Script IncreaseClusterTimeouts 
        {
            SetScript  = "(Get-Cluster).SameSubnetDelay = 2000; (Get-Cluster).SameSubnetThreshold = 15; (Get-Cluster).CrossSubnetDelay = 3000; (Get-Cluster).CrossSubnetThreshold = 15"
            TestScript = "(Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15"
            GetScript  = "@{Ensure = if ((Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15) {'Present'} else {'Absent'}}"
            PsDscRunAsCredential = $DomainCreds
            DependsOn  = "[Script]ClusterWitness"
        }


        Script FirewallRuleProbePort {
            SetScript  = "Remove-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -ErrorAction SilentlyContinue; New-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -Profile Domain -Direction Inbound -Action Allow -Enabled True -Protocol 'tcp' -LocalPort ${ListenerProbePort}"
            TestScript = "(Get-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -ErrorAction SilentlyContinue | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue).LocalPort -eq ${ListenerProbePort}"
            GetScript  = "@{Ensure = if ((Get-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -ErrorAction SilentlyContinue | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue).LocalPort -eq ${ListenerProbePort}) {'Present'} else {'Absent'}}"
            DependsOn  = "[Script]IncreaseClusterTimeouts"
        }
        }
        else 
        {

        Script IncreaseClusterTimeouts 
        {
            SetScript  = "(Get-Cluster).SameSubnetDelay = 2000; (Get-Cluster).SameSubnetThreshold = 15; (Get-Cluster).CrossSubnetDelay = 3000; (Get-Cluster).CrossSubnetThreshold = 15"
            TestScript = "(Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15"
            GetScript  = "@{Ensure = if ((Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15) {'Present'} else {'Absent'}}"
            PsDscRunAsCredential = $DomainCreds
            DependsOn  = "[Script]AddClusterDisks"
        }


        Script FirewallRuleProbePort {
            SetScript  = "Remove-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -ErrorAction SilentlyContinue; New-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -Profile Domain -Direction Inbound -Action Allow -Enabled True -Protocol 'tcp' -LocalPort ${ListenerProbePort}"
            TestScript = "(Get-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -ErrorAction SilentlyContinue | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue).LocalPort -eq ${ListenerProbePort}"
            GetScript  = "@{Ensure = if ((Get-NetFirewallRule -DisplayName 'Failover Cluster - Probe Port' -ErrorAction SilentlyContinue | Get-NetFirewallPortFilter -ErrorAction SilentlyContinue).LocalPort -eq ${ListenerProbePort}) {'Present'} else {'Absent'}}"
            DependsOn  = "[Script]IncreaseClusterTimeouts"
        }
        }

        LocalConfigurationManager {
            ActionAfterReboot = "ContinueConfiguration"
            ConfigurationMode = "ApplyAndMonitor"
            RebootNodeIfNeeded = $True
        }
    }
}